import data
pokemon_data = data.get_data()

def dry_compare(pokemonOne, pokemonTwo, identifier):  # General function
    pokemonOne_data = next((pokemon for pokemon in pokemon_data if pokemon['name'] == pokemonOne), None)
    pokemonTwo_data = next((pokemon for pokemon in pokemon_data if pokemon['name'] == pokemonTwo), None)
    
    if pokemonOne_data and pokemonTwo_data and identifier in ['hp', 'attack', 'defense']:  # Check if data exists and if the identifier is a valid choice
        statOne = pokemonOne_data[identifier]
        statTwo = pokemonTwo_data[identifier]
        
        return float(statOne - statTwo)
    else:
        return None
    
def attack_diff(pokemonOne, pokemonTwo):
    return dry_compare(pokemonOne, pokemonTwo, 'attack')

def defense_diff(pokemonOne, pokemonTwo):
    return dry_compare(pokemonOne, pokemonTwo, 'defense')

def hp_diff(pokemonOne, pokemonTwo):
    return dry_compare(pokemonOne, pokemonTwo, 'hp')

def combat_power_diff(pokemonOne, pokemonTwo):
    pokemonOne_data = next((pokemon for pokemon in pokemon_data if pokemon['name'] == pokemonOne), None)
    pokemonTwo_data = next((pokemon for pokemon in pokemon_data if pokemon['name'] == pokemonTwo), None)
    
    if pokemonOne_data and pokemonTwo_data:  # Check if the pokemon exist (Not equal to None)
        
        # Statistics for the first Pokemon
        attackOne = pokemonOne_data['attack']
        defenseOne = pokemonOne_data['defense']
        sp_attackOne = pokemonOne_data['sp_attack']
        sp_defenseOne = pokemonOne_data['sp_defense']
        speedOne = pokemonOne_data['speed']
        hpOne = pokemonOne_data['hp']
        
        CPAttackOne = 2 * round((attackOne**0.5) * (sp_attackOne**0.5) + (speedOne**0.5))
        CPDefenseOne = 2 * round((defenseOne**0.5) * (sp_defenseOne**0.5) + (speedOne**0.5))
        CPStaminaOne = 2 * hpOne
        MaxCP1 = (CPAttackOne + 15) * ((CPDefenseOne + 15)**0.5) * ((CPStaminaOne + 15)**0.5) * (0.7903001**2) / 10
        
        # Statistics for the second Pokemon
        attackTwo = pokemonTwo_data['attack']
        defenseTwo = pokemonTwo_data['defense']
        sp_attackTwo = pokemonTwo_data['sp_attack']
        sp_defenseTwo = pokemonTwo_data['sp_defense']
        speedTwo = pokemonTwo_data['speed']
        hpTwo = pokemonTwo_data['hp']
        
        CPAttackTwo = 2 * round((attackTwo**0.5) * (sp_attackTwo**0.5) + (speedTwo**0.5))
        CPDefenseTwo = 2 * round((defenseTwo**0.5) * (sp_defenseTwo**0.5) + (speedTwo**0.5))
        CPStaminaTwo = 2 * hpTwo
        MaxCP2 = (CPAttackTwo + 15) * ((CPDefenseTwo + 15)**0.5) * ((CPStaminaTwo + 15)**0.5) * (0.7903001**2) / 10
        
        return float(MaxCP1 - MaxCP2)
    
    else:
        return None