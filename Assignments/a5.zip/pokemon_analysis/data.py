import os
import json

fname = os.path.join(os.path.dirname(__file__), 'pokemon.json')

data = None  # module variable to store loaded data

def get_data():
    global data
    
    if data is None:  # load data if it hasn't already been 
        with open(fname, 'r') as file:
            data = json.load(file)
            
    return data