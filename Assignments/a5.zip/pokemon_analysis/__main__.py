import argparse
from pokemon_analysis import generation, compare

parser = argparse.ArgumentParser()
subparsers = parser.add_subparsers(dest='command')

# Generation subcommand
generation_parser = subparsers.add_parser('generation')
generation_parser.add_argument('gen', type=int)

# Compare subcommand
compare_parser = subparsers.add_parser('compare')
compare_parser.add_argument('pokemonOne', type=str)
compare_parser.add_argument('pokemonTwo', type=str)

args = parser.parse_args()

if __name__ == '__main__':
    if args.command == 'generation':
        gen_stats = generation.generation_ranges(args.gen)
        print(f"Generation {args.gen}:")
        for stat, (min_val, max_val) in gen_stats.items():
            print(f"  {stat}: {min_val:.1f}-{max_val:.1f}")

    elif args.command == 'compare':
        combatpower_diff = compare.combat_power_diff(args.pokemonOne, args.pokemonTwo)
        if combatpower_diff is not None:
            if (combatpower_diff >= 0):
                print(f"{args.pokemonOne} has +{combatpower_diff:.6f} combat power than {args.pokemonTwo}")
            else:
                print(f"{args.pokemonOne} has {combatpower_diff:.6f} combat power than {args.pokemonTwo}")
        else:
            print(f"Error: Missing Pokemon data.")
