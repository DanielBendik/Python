from collections import Counter
import data
pokemon_data = data.get_data()

def generation_types(gen):
    generation_data = [pokemon for pokemon in pokemon_data if pokemon['generation'] == gen]  # Filter by generation number
    type_counts = Counter(pokemon['primary_type'] for pokemon in generation_data)  # Count total numbr of pokemon for each primary type
    return type_counts

def generation_ranges(gen):
    generation_data = [pokemon for pokemon in pokemon_data if pokemon['generation'] == gen]  # Filter by generation number
    
    min_hp = min(pokemon['hp'] for pokemon in generation_data)  # Get min hp of generation
    max_hp = max(pokemon['hp'] for pokemon in generation_data)  # Get max hp of generation
    
    min_atk = min(pokemon['attack'] for pokemon in generation_data)  # Get min attack of generation
    max_atk = max(pokemon['attack'] for pokemon in generation_data)  # Get max attack of generation
    
    min_def = min(pokemon['defense'] for pokemon in generation_data)  # Get min defense of generation
    max_def = max(pokemon['defense'] for pokemon in generation_data)  # Get max defense of generation
    
    stats = {    # Create a dictionary of these values
        'hp': (min_hp, max_hp),
        'attack': (min_atk, max_atk),
        'defense': (min_def, max_def)
    }
    
    return stats
